import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

function UpdateProduct() {
  const { id } = useParams(); // Get product ID from the URL
  const navigate = useNavigate();
  const merchantId = localStorage.getItem("merchantId"); // Retrieve merchantId from localStorage

  const [data, setData] = useState({
    name: '',
    description: '',
    price: '',
    quantity: '',
  });

//   useEffect(() => {
//     fetch(`http://localhost:8080/products/${id}`)
//       .then((response) => response.json())
//       .then((product) => {
//         setData({
//           name: product.name,
//           description: product.description,
//           price: product.price,
//           quantity: product.stock,
//           type: product.type, // Add type
//           usp: product.usp, // Add usp
//           imageUrl: product.imageUrl, // Add image URL
//         });
//       })
//       .catch((err) => console.error("Error fetching product details:", err));
//   }, [id]);
useEffect(() => {
    fetch(`http://localhost:8080/products/${id}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Failed to fetch product. Status: ${response.status}`);
        }
        return response.json(); // Parse response as JSON
      })
      .then((product) => {
        setData({
          name: product.name || "",
          description: product.description || "",
          price: product.price || "",
          quantity: product.stock || "",
          type: product.type || "",
          usp: product.usp || "",
          imageUrl: product.imageUrl || "",
        });
      })
      .catch((err) => {
        console.error("Error fetching product details:", err);
        alert("Failed to load product details. Please try again.");
      });
  }, [id]);
  

  
//   const updateProduct = async () => {
//     if (!data.name || !data.description || !data.price || !data.quantity || !data.type || !data.usp || !data.imageUrl) {
//       alert("Please fill all fields.");
//       return;
//     }
  
//     try {
//       const response = await fetch(
//         `http://localhost:8080/products/update/${id}/${merchantId}`,
//         {
//           method: "PUT",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify(data), // Send all fields
//         }
//       );
  
//       if (response.ok) {
//         alert("Product updated successfully!");
//         navigate("/view-products");
//       } else {
//         alert("Failed to update product.");
//       }
//     } catch (err) {
//       console.error("Error updating product:", err);
//       alert("Error updating product.");
//     }
//   };
const updateProduct = async () => {
    const updatedData = {
      name: data.name,
      description: data.description,
      price: data.price,
      quantity: data.quantity,
      type: data.type, // Ensure type is sent
      usp: data.usp, // Ensure usp is sent
      imageUrl: data.imageUrl, // Ensure imageUrl is sent
    };
  
    const response = await fetch(`http://localhost:8080/products/update/${id}/${merchantId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    });
  
    if (response.ok) {
      alert("Product updated successfully!");
      navigate("/view-products");
    } else {
      alert("Failed to update product.");
    }
  };
  
    const handleChange = (e) => {
        const { name, value } = e.target;
        setData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
        }
  

  return (
    <div>
    <h2>Update Product</h2>
    <input
      name="name"
      placeholder="Name"
      onChange={(e) => setData({ ...data, name: e.target.value })}
      value={data.name}
    />
    <input
      name="description"
      placeholder="Description"
      onChange={(e) => setData({ ...data, description: e.target.value })}
      value={data.description}
    />
    <input
      name="price"
      type="number"
      placeholder="Price"
      onChange={(e) => setData({ ...data, price: e.target.value })}
      value={data.price}
    />
    <input
      name="quantity"
      type="number"
      placeholder="Quantity"
      onChange={(e) => setData({ ...data, quantity: e.target.value })}
      value={data.quantity}
    />
    <input
      name="type"
      placeholder="Type"
      onChange={(e) => setData({ ...data, type: e.target.value })}
      value={data.type}
    />
    <input
      name="usp"
      placeholder="Unique Selling Proposition"
      onChange={(e) => setData({ ...data, usp: e.target.value })}
      value={data.usp}
    />
    <input
      name="imageUrl"
      placeholder="Image URL"
      onChange={(e) => setData({ ...data, imageUrl: e.target.value })}
      value={data.imageUrl}
    />
    <button onClick={updateProduct}>Update</button>
  </div>
  
  );
}

export default UpdateProduct;
