import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const EditProfile = () => {
  const navigate = useNavigate();

  // State for profile details
  const [profile, setProfile] = useState({
    _id: "",
    name: "",
    email: "",
    phone: "",
    address: "",
    role: "",
    password: "",
    merchantId: "",
  });
  // useEffect(() => {
  //   const email = localStorage.getItem("email");
  
  //   if (!email) {
  //     console.error("Merchant email not found in localStorage.");
  //     return;
  //   }
  
  //   fetch(`http://localhost:8080/users/id-by-email/${email}`)
  //     .then(res => {
  //       if (!res.ok) {
  //         throw new Error("Merchant ID fetch failed.");
  //       }
  //       return res.text();
  //     })
  //     .then(merchantId => {
  //       if (!merchantId || merchantId === "User not found") {
  //         throw new Error("Merchant ID is invalid.");
  //       }
  
  //       return fetch(`http://localhost:8080/users/merchant/${merchantId}`);
  //     })
  //     .then(res => {
  //       if (!res.ok) {
  //         throw new Error("Merchant details fetch failed.");
  //       }
  //       return res.json();
  //     })
  //     .then(data => {
  //       setProfile({
  //         name: data.name,
  //         email: data.email,
  //         phone: data.phone,
  //         address: data.address,
  //       });
  
  //       // Optional: store updated data
  //       localStorage.setItem("merchantName", data.email);
    
  //       localStorage.setItem("merchantAddress", data.address);
  //       localStorage.setItem("merchantName", data.name);
  //       localStorage.setItem("merchantPhone", data.phone);
  //       localStorage.setItem("merchantAddress", data.address);
  //     })
  //     .catch(err => {
  //       console.error("Failed to fetch profile:", err.message);
  //     });
  // }, []);
  
  useEffect(() => {
    const userDetails = {
      _id: localStorage.getItem("_id"),
      name: localStorage.getItem("name"),
      email: localStorage.getItem("email"),
      phone: localStorage.getItem("phone"),
      address: localStorage.getItem("address"),
      role: localStorage.getItem("role"),
      password: localStorage.getItem("password"),
      merchantId: localStorage.getItem("merchantId"), // Directly use merchantId from localStorage
    };
  
    console.log("Loaded Profile Data:", userDetails); // Debug to confirm values
    setProfile(userDetails); // Populate state without backend calls
  }, []);
  
  

  
  const handleSave = async () => {
    try {
      const updatedProfile = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        address: document.getElementById("address").value,
        password: document.getElementById("password").value,
      };
  
      const response = await fetch(`http://localhost:8080/users/merchant/${profile.merchantId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedProfile),
      });
  
      if (response.ok) {
        // Update localStorage after a successful save
        localStorage.setItem("name", updatedProfile.name);
        localStorage.setItem("email", updatedProfile.email);
        localStorage.setItem("phone", updatedProfile.phone);
        localStorage.setItem("address", updatedProfile.address);
        localStorage.setItem("password", updatedProfile.password);
  
        alert("Profile updated successfully!");
        navigate("/merchant-profile");
      } else {
        alert("Failed to update profile.");
      }
    } catch (error) {
      console.error("Error saving profile:", error);
      alert("Failed to update profile.");
    }
  };
  
  return (
    <div style={styles.container}>
      <h2>Edit Profile</h2>
      <form style={styles.form}>
        <input
          style={styles.input}
          type="text"
          id="name"
          defaultValue={profile.name}
          placeholder="Name"
        />
        <input
          style={styles.input}
          type="email"
          id="email"
          defaultValue={profile.email}
          placeholder="Email"
        />
        <input
          style={styles.input}
          type="password"
          id="password"
          defaultValue={profile.password}
          placeholder="Password"
        />
        <input
          style={styles.input}
          type="tel"
          id="phone"
          defaultValue={profile.phone}
          placeholder="Phone Number"
        />
        <textarea
          style={styles.input}
          id="address"
          defaultValue={profile.address}
          placeholder="Address"
        />
        {profile.role === "merchant" && (
          <input
            style={styles.input}
            type="text"
            defaultValue={profile.merchantId}
            placeholder="Merchant ID"
            disabled
          />
        )}
     
        <button style={styles.button} onClick={handleSave} type="button">
          Save Changes
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    padding: "30px",
    fontFamily: "Segoe UI, sans-serif",
    backgroundColor: "#f9f9f9",
    minHeight: "100vh",
    textAlign: "center",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    maxWidth: "400px",
    margin: "0 auto",
  },
  input: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "10px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};

export default EditProfile;
