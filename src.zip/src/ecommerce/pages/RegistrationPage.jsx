// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// export default function RegisterPage() {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [role, setRole] = useState("");
//   const [merchantId, setMerchantId] = useState(""); // Added state for Merchant ID
//   const [phone, setPhone] = useState("");
// const [address, setAddress] = useState("");

//   const navigate = useNavigate(); // for redirecting

//   const handleRegister = async () => {
//     if (!name || !email || !password || (role === "merchant" && (!merchantId || !phone || !address))) {
//       alert("Please fill all fields, including phone and address.");
//       return;
//     }
   
//   try {
//     const response = await fetch("http://localhost:8080/register", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({ name, email, password, role, merchantId, phone, address }),
//     });

    

//       if (response.ok) {
//         const data = await response.json();
//         console.log("Registered:", data);
//         alert("Registration successful! Redirecting to login...");
//         navigate("/login"); // redirect to login page
//       } else {
//         const errorMsg = await response.text();
//         alert("Registration failed: " + errorMsg);
//       }
//     } catch (error) {
//       console.error("Error during registration:", error);
//       alert("Server is down or unreachable");
//     }
//   };

//   return (
//     <div style={styles.container}>
//       <h2>Register</h2>
//       <input
//         style={styles.input}
//         type="text"
//         placeholder="Full Name"
//         value={name}
//         onChange={(e) => setName(e.target.value)}
//       />
//       <input
//         style={styles.input}
//         type="email"
//         placeholder="Email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//       />
//       <input
//         style={styles.input}
//         type="password"
//         placeholder="Password"
//         value={password}
//         onChange={(e) => setPassword(e.target.value)}
//       />
//       <select
//         style={styles.input}
//         value={role}
//         onChange={(e) => setRole(e.target.value)}
//       >
//         <option value="user">End User</option>
//         <option value="merchant">Merchant</option>
//       </select>
//       {role === "merchant" && (
//         <input
//           style={styles.input}
//           type="text"
//           placeholder="Enter Merchant ID"
//           value={merchantId}
//           onChange={(e) => setMerchantId(e.target.value)} // Handle Merchant ID input
//         />
//       )}
//       <button style={styles.button} onClick={handleRegister}>
//         Register
//       </button>
//     </div>
//   );
// }

// const styles = {
//   container: {
//     maxWidth: "300px",
//     margin: "50px auto",
//     padding: "20px",
//     border: "1px solid #ccc",
//     borderRadius: "10px",
//     textAlign: "center",
//   },
//   input: {
//     display: "block",
//     width: "100%",
//     padding: "10px",
//     marginBottom: "10px",
//     borderRadius: "5px",
//     border: "1px solid #ccc",
//   },
//   button: {
//     width: "100%",
//     padding: "10px",
//     backgroundColor: "#28a745",
//     color: "white",
//     border: "none",
//     borderRadius: "5px",
//   },
// };
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState(""); // User role (merchant/user)
  const [merchantId, setMerchantId] = useState(""); // Only for merchants
  const [phone, setPhone] = useState(""); // Phone (mandatory)
  const [address, setAddress] = useState(""); // Address (mandatory)

  const navigate = useNavigate();

  const handleRegister = async () => {
    if (!name || !email || !password || !phone || !address) {
      alert("Please fill out all required fields.");
      return;
    }
  
    try {
      const response = await fetch("http://localhost:8080/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          email,
          password,
          role,
          merchantId: role === "merchant" ? merchantId : null, // Only send merchantId for merchants
          phone,
          address,
        }),
      });
  
      if (response.ok) {
        alert("Registration successful!");
        navigate("/login");
      } else {
        const errorMsg = await response.text();
        alert("Registration failed: " + errorMsg);
      }
    } catch (error) {
      console.error("Error during registration:", error);
      alert("Server is down or unreachable.");
    }
  };
  

  return (
    <div style={styles.container}>
      <h2>Register</h2>
      <input
        style={styles.input}
        type="text"
        placeholder="Full Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        style={styles.input}
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        style={styles.input}
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <select
        style={styles.input}
        value={role}
        onChange={(e) => setRole(e.target.value)}
      >
        <option value="">Select Role</option>
        <option value="user">End User</option>
        <option value="merchant">Merchant</option>
      </select>
      {role === "merchant" && (
        <input
          style={styles.input}
          type="text"
          placeholder="Enter Merchant ID"
          value={merchantId}
          onChange={(e) => setMerchantId(e.target.value)}
        />
      )}
      <input
        style={styles.input}
        type="tel"
        placeholder="Phone Number"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
      />
      <textarea
        style={styles.input}
        placeholder="Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <button style={styles.button} onClick={handleRegister}>
        Register
      </button>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "400px",
    margin: "50px auto",
    padding: "20px",
    border: "1px solid #ccc",
    borderRadius: "10px",
    textAlign: "center",
  },
  input: {
    display: "block",
    width: "100%",
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  button: {
    width: "100%",
    padding: "10px",
    backgroundColor: "#28a745",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};
