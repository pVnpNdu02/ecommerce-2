// import React from "react";
// import { useNavigate } from "react-router-dom";

// const SellerDashboard = () => {
//   const navigate = useNavigate();

//   const handleAddProduct = () => {
//     navigate("/add-product");
//   };

//   const handleViewEditProducts = () => {
//     navigate(`/view-products/`); // Pass merchantId as part of the URL
//   };

//   const handleViewOrders = () => {
//     navigate("/view-orders");
//   };

//   const handleEditProfile = () => {
//     navigate("/edit-profile");
//   };

//   const handleLogout = () => {
//     navigate("/");
//   };

//   return (
//     <div style={styles.container}>
//       {/* Profile Top Right */}
//       <div style={styles.header}>
//         <h2>Seller Dashboard</h2>
//         <div style={styles.profile}>
//           <span>👤 </span>
//         </div>
//       </div>

//       {/* Blocks */}
//       <div style={styles.grid}>
//         <div style={styles.card}>
//           <h3>Products</h3>
//           <button style={styles.button} onClick={handleAddProduct}>
//             ➕ Add New Product
//           </button>
//           <button style={styles.button} onClick={handleViewEditProducts}>
//             📦 Update Products
//           </button>
//         </div>

//         <div style={styles.card}>
//           <h3>Orders</h3>
//           <button style={styles.button} onClick={handleViewOrders}>
//             📃 View Orders
//           </button>
//         </div>

//         <div style={styles.card}>
//           <h3>Profile</h3>
//           <button style={styles.button} onClick={handleEditProfile}>
//             ✏️ Edit Profile
//           </button>
//           <button style={styles.logoutButton} onClick={handleLogout}>
//             🚪 Logout
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// const styles = {
//   container: {
//     padding: "30px",
//     fontFamily: "Segoe UI, sans-serif",
//     backgroundColor: "#f9f9f9",
//     minHeight: "100vh",
//   },
//   header: {
//     display: "flex",
//     justifyContent: "space-between",
//     alignItems: "center",
//     marginBottom: "40px",
//   },
//   profile: {
//     fontSize: "16px",
//     backgroundColor: "#e0e0e0",
//     padding: "10px 20px",
//     borderRadius: "20px",
//   },
//   grid: {
//     display: "grid",
//     gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
//     gap: "20px",
//   },
//   card: {
//     backgroundColor: "#ffffff",
//     padding: "20px",
//     borderRadius: "15px",
//     boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
//     textAlign: "center",
//   },
//   button: {
//     width: "100%",
//     padding: "12px",
//     margin: "10px 0",
//     backgroundColor: "#007bff",
//     color: "white",
//     border: "none",
//     borderRadius: "8px",
//     fontSize: "15px",
//     cursor: "pointer",
//   },
//   logoutButton: {
//     width: "100%",
//     padding: "12px",
//     marginTop: "10px",
//     backgroundColor: "#d32f2f",
//     color: "white",
//     border: "none",
//     borderRadius: "8px",
//     fontSize: "15px",
//     cursor: "pointer",
//   },
// };

// export default SellerDashboard;
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const SellerDashboard = () => {
  const navigate = useNavigate();
  const [merchantName, setMerchantName] = useState("Merchant"); // Default name

  useEffect(() => {
    // Fetch merchant name from localStorage or API
    const name = localStorage.getItem("merchantName") || "Merchant";
    setMerchantName(name);
  }, []);

  const handleViewProfile = () => {
    navigate("/merchant-profile"); // Navigate to profile page
  };

  const handleAddProduct = () => {
    navigate("/add-product");
  };

  const handleViewEditProducts = () => {
    navigate("/view-products");
  };
  

  const handleViewOrders = () => {
    navigate("/view-orders");
  };

  const handleLogout = () => {
    navigate("/");
  };
  const handleEditProfile = () => {
    navigate("/edit-profile"); // Redirect to Edit Profile page
  };
  
return (
  <div style={styles.container}>
    <div style={styles.grid}>
      {/* Products Section */}
      <div style={styles.card}>
        <h3>Products</h3>
        <button style={styles.button} onClick={handleAddProduct}>
          ➕ Add New Product
        </button>
        <button style={styles.button} onClick={handleViewEditProducts}>
          📦 Manage Products
        </button>
      </div>

      {/* Orders Section */}
      <div style={styles.card}>
        <h3>Orders</h3>
        <button style={styles.button} onClick={handleViewOrders}>
          📃 View Orders
        </button>
      </div>

      {/* Profile Section */}
      <div style={styles.card}>
        <h3>Profile</h3>
        <button style={styles.button} onClick={handleEditProfile}>
          ✏️ Edit Profile
        </button>
        <button style={styles.logoutButton} onClick={handleLogout}>
          🚪 Logout
        </button>
      </div>
    </div>
  </div>
);
};

const styles = {
  container: {
    padding: "30px",
    fontFamily: "Segoe UI, sans-serif",
    backgroundColor: "#f9f9f9",
    minHeight: "100vh",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "30px",
  },
  logoContainer: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
  },
  logo: {
    borderRadius: "50%",
    width: "50px",
    height: "50px",
    marginRight: "10px",
  },
  merchantName: {
    fontSize: "18px",
    fontWeight: "bold",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: "20px",
  },
  card: {
    backgroundColor: "#ffffff",
    padding: "20px",
    borderRadius: "15px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    textAlign: "center",
  },
  button: {
    width: "100%",
    padding: "12px",
    margin: "10px 0",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "8px",
    fontSize: "15px",
    cursor: "pointer",
  },
  logoutButton: {
    backgroundColor: "#d32f2f",
    color: "#fff",
    padding: "10px 20px",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },
};

export default SellerDashboard;
