import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const ViewProductsPage = () => {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchProducts = () => {
    const merchantId = localStorage.getItem("merchantId");

    if (!merchantId) {
      alert("Please login first.");
      navigate("/login");
      return;
    }

    setLoading(true);
    setError("");

    fetch(`http://localhost:8080/products/merchant/${merchantId}`)
      .then((response) => response.json())
      .then((data) => setProducts(data))
      .catch((err) => {
        console.error("Error fetching products:", err);
        setError("Failed to load products");
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      fetch(`http://localhost:8080/products/delete/${id}`, {
        method: "DELETE",
      })
        .then((response) => {
          if (response.ok) {
            alert("Product deleted successfully!");
            fetchProducts();
          } else {
            alert("Failed to delete product.");
          }
        })
        .catch((err) => console.error("Error deleting product:", err));
    }
  };

  const handleEdit = (product) => {
    // Simply navigate to the update page without adding merchantId
    navigate(`/update-product/${product.id}`);
  };
  return (
    <div>
      <h3>View/Delete Products</h3>

      {loading && <p>Loading products...</p>}
      {error && <p>{error}</p>}

      {products.length > 0 ? (
        products.map((product) => (
          <div key={product.id} style={{ border: "1px solid gray", padding: 10, margin: 10 }}>
            <h4>{product.name}</h4>
            <p>{product.description}</p>
            <p>Type: {product.type} | USP: {product.usp}</p>
            <p>Price: ₹{product.price} | Quantity: {product.stock}</p>
            <button onClick={() => handleEdit(product)}>Edit</button>
            <button onClick={() => handleDelete(product.id)} style={{ marginLeft: "10px" }}>
              Delete
            </button>
          </div>
        ))
      ) : (
        <p>No products available for this merchant.</p>
      )}
    </div>
  );
};

export default ViewProductsPage;
