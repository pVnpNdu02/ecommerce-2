import React, { useState } from "react";
import api from "../../api.js";  

function AddProduct() {
  const [product, setProduct] = useState({
    name: '',
    type: '',
    usp: '',
    description: '',
    imageUrl: '',
    price: '',
    quantity: '',
    merchantId: '', // Added merchantId field
  });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check for null or empty values
    for (const key in product) {
        if (product[key] === '') {
          alert(`Please fill the ${key} field.`);
          return;
        }
      }

    try {
      // Prepare the data to send, adding merchant-specific information
      const productData = {
        ...product,
        merchants: [{
          merchantId: product.merchantId,  // Merchant-specific ID
          price: product.price,
          stock: product.quantity, // Quantity as stock
        }]
      };
      await api.post(`/products/add?merchantId=${product.merchantId}`, productData);

      alert('Product added!');
    } catch (err) {
      console.error(err);
      alert('Error adding product');
    }
  };

  return (
    <div>
      <h2>Add Product</h2>
      <form onSubmit={handleSubmit}>
        <input 
          name="name" 
          placeholder="Name" 
          onChange={handleChange} 
          value={product.name}
          required 
        />
        <input 
          name="type" 
          placeholder="Type" 
          onChange={handleChange} 
          value={product.type}
          required 
        />
        <input 
          name="usp" 
          placeholder="USP" 
          onChange={handleChange} 
          value={product.usp}
          required 
        />
        <textarea 
          name="description" 
          placeholder="Description" 
          onChange={handleChange} 
          value={product.description}
          required 
        />
        <input 
          name="imageUrl" 
          placeholder="Image URL" 
          onChange={handleChange} 
          value={product.imageUrl}
          required 
        />
        <input 
          name="price" 
          placeholder="Price" 
          onChange={handleChange} 
          value={product.price}
          required 
        />
        <input 
          name="quantity" 
          placeholder="Quantity" 
          onChange={handleChange} 
          value={product.quantity}
          required 
        />
        <input 
          name="merchantId" 
          placeholder="Merchant ID" 
          onChange={handleChange} 
          value={product.merchantId}
          required 
        />
      
        <br />
        <button type="submit">Add Product</button>
      </form>
    </div>
  );
}

export default AddProduct;
