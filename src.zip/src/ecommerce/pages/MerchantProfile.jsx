import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const MerchantProfile = () => {
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });
  const navigate = useNavigate();
  useEffect(() => {
    // First try to get merchantId directly from localStorage
    const merchantId = localStorage.getItem("merchantId");
    const email = localStorage.getItem("email");
    
    if (merchantId) {
        // If we have merchantId, use it directly
        fetchMerchantProfile(merchantId);
    } else if (email) {
        // Fallback to email lookup if no merchantId
        fetch(`http://localhost:8080/users/id-by-email/${email}`)
            .then(res => {
                if (!res.ok) throw new Error(`Failed to fetch merchantId. Status: ${res.status}`);
                return res.text();
            })
            .then(merchantId => {
                if (!merchantId || merchantId === "User not found") {
                    throw new Error("Invalid merchantId received.");
                }
                // Store the merchantId for future use
                localStorage.setItem("merchantId", merchantId);
                return fetchMerchantProfile(merchantId);
            })
            .catch(err => {
                console.error("Error:", err.message);
                alert(err.message || "Failed to fetch profile");
            });
    } else {
        alert("No authentication data found. Please log in again.");
    }

    function fetchMerchantProfile(merchantId) {
        fetch(`http://localhost:8080/users/merchant/${merchantId}`)
            .then(res => {
                if (!res.ok) throw new Error(`Failed to fetch merchant details. Status: ${res.status}`);
                return res.json();
            })
            .then(data => {
                setProfile({
                    name: data.name,
                    email: data.email,
                    phone: data.phone,
                    address: data.address,
                });
                // Update localStorage
                localStorage.setItem("merchantName", data.name);
                localStorage.setItem("merchantPhone", data.phone);
                localStorage.setItem("merchantAddress", data.address);
            })
            .catch(err => {
                console.error("Failed to fetch profile:", err.message);
                alert(err.message || "Failed to fetch merchant profile");
            });
    }
}, []);
  
  const handleEdit = () => {
    // Redirect to edit profile page
    navigate("/edit-profile");
  };

  return (
    <div style={styles.container}>
      <h2>Merchant Profile</h2>
      <div style={styles.profileCard}>
        <p><strong>Name:</strong> {profile.name}</p>
        <p><strong>Email:</strong> {profile.email}</p>
        <p><strong>Phone:</strong> {profile.phone}</p>
        <p><strong>Address:</strong> {profile.address}</p>
        <button style={styles.button} onClick={() => navigate("/edit-profile")}>
  ✏️ Edit Profile
</button>

      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: "30px",
    fontFamily: "Segoe UI, sans-serif",
    backgroundColor: "#f9f9f9",
    minHeight: "100vh",
    textAlign: "center",
  },
  profileCard: {
    backgroundColor: "#ffffff",
    padding: "20px",
    borderRadius: "15px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    margin: "0 auto",
    width: "300px",
  },
  button: {
    marginTop: "20px",
    padding: "10px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};

export default MerchantProfile;
