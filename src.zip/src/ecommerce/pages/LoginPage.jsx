import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  
  const handleLogin = async () => {
    try {
      const response = await fetch("http://localhost:8080/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
  
      if (response.ok) {
        const data = await response.json();
        console.log("Login Response:", data); // Log the response to debug
  
        // Store _id correctly
        localStorage.setItem("_id", data._id); // This should now be a valid string
        localStorage.setItem("name", data.name);
        localStorage.setItem("email", data.email);
        localStorage.setItem("phone", data.phone);
        localStorage.setItem("address", data.address);
        localStorage.setItem("role", data.role);
        localStorage.setItem("password", data.password);
        if (data.merchantId) localStorage.setItem("merchantId", data.merchantId);
  
        // Redirect based on role
        if (data.role === "merchant") {
          navigate("/merchant");
        } else {
          navigate("/user");
        }
      } else {
        alert("Invalid credentials");
      }
    } catch (error) {
      console.error("Login failed:", error);
      alert("Server error.");
    }
  };
  
  
  
  
  

  

  return (
    <div style={styles.container}>
      <h2>Login</h2>
      <input
        style={styles.input}
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        style={styles.input}
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button style={styles.button} onClick={handleLogin}>Login</button>

      <p style={{ margin: "10px 0" }}>New here?</p>
      <button style={styles.registerButton} onClick={() => navigate("/register")}>
        Register as New User
      </button>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "350px",
    margin: "60px auto",
    padding: "25px",
    border: "1px solid #e0e0e0",
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    textAlign: "center",
    backgroundColor: "#ffffff",
    fontFamily: "Segoe UI, sans-serif",
  },
  input: {
    display: "block",
    width: "100%",
    padding: "12px",
    marginBottom: "15px",
    borderRadius: "6px",
    border: "1px solid #ccc",
    fontSize: "14px",
  },
  button: {
    width: "100%",
    padding: "12px",
    backgroundColor: "#ff6f00",
    color: "#fff",
    border: "none",
    fontWeight: "bold",
    fontSize: "15px",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "0.3s ease",
  },
  registerButton: {
    width: "100%",
    padding: "12px",
    backgroundColor: "#1b5e20",
    color: "#fff",
    border: "none",
    fontWeight: "bold",
    fontSize: "15px",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "0.3s ease",
  },
};

// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// function LoginPage() {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const handleLogin = () => {
//     if (!email || !password) {
//       alert("Please enter email and password");
//       return;
//     }

//     // Placeholder login
//     console.log("Login:", email);
//     navigate("/merchant");
//   };

//   return (
//     <div>
//       <h2>Login</h2>
//       <input
//         type="email"
//         placeholder="Enter Email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//       />

//       <input
//         type="password"
//         placeholder="Enter Password"
//         value={password}
//         onChange={(e) => setPassword(e.target.value)}
//       />

//       <button onClick={handleLogin}>Login</button>

//       <p>Don't have an account?</p>
//       <button onClick={() => navigate("/register")}>Register</button>
//     </div>
//   );
// }

// export default LoginPage;
