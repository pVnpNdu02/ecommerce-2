import React from "react";
import {  Routes, Route, Link, useLocation } from "react-router-dom";
import SellerDashboard from "./ecommerce/pages/sellerPage";
import LoginPage from "./ecommerce/pages/LoginPage";
import RegisterPage from "./ecommerce/pages/RegistrationPage";
import AddProduct from "./ecommerce/pages/AddProd";
import ViewProductsPage from "./ecommerce/pages/ViewProd";
import UpdateProduct from "./ecommerce/pages/UpdateProd";
import MerchantProfile from "./ecommerce/pages/MerchantProfile";
import EditProfile from "./ecommerce/pages/EditProfile";

function App() {
  return (
    <MainLayout />
  );
}



function MainLayout() {
  const location = useLocation();
  const isHome = location.pathname === "/";

  return (
    <div style={{ textAlign: "center", marginTop: "30px" }}>
      {isHome && (
        <nav>
          <Link to="/" style={styles.link}>Login</Link> |{" "}
          <Link to="/register" style={styles.link}>Register</Link>
        </nav>
      )}
  <Routes>
        {/* Auth Routes */}
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Merchant Dashboard */}
        <Route path="/merchant" element={<SellerDashboard />} />

        {/* Merchant Operations */}
        <Route path="/add-product" element={<AddProduct/>} />
        <Route path="/view-products" element={<ViewProductsPage />} />

        {/* <Route path="/update-products" element={<UpdateProduct/>} /> */}
        <Route path="/update-product/:id" element={<UpdateProduct />} />
        <Route path="/merchant-profile" element={<MerchantProfile />} />
        <Route path="/edit-profile" element={<EditProfile />} />

           
      </Routes>
    </div>
  );
}

const styles = {
  link: {
    margin: "0 10px",
    textDecoration: "none",
    color: "#007bff"
  }
};

export default App;
